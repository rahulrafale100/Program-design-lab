#include<stdio.h>
#include<stdlib.h>
int c=0;
void merge(int a[],int s,int m,int e){
	int n1=m-s+1;
	int n2=e-m;
	int al[n1+1],ar[n2+1];
	for(int i=0;i<n1;i++)
        al[i]=a[s+i];
    for(int j=0;j<n2;j++)
        ar[j]=a[m+1+j];
        al[n1]=5000;
        ar[n2]=5000;
    int i=0,j=0;
for(int p=s;p<=e;p++){
    if(al[i]<=ar[j]){
        a[p]=al[i];i++;
        c++;}
        else{
            a[p]=ar[j];
            j++;
            c++;
        }
}
}
void merge_sort(int a[],int s,int e){
	if(s<e){
		int m=(s+e)/2;
		merge_sort(a,s,m);
		merge_sort(a,m+1,e);
		merge(a,s,m,e);
	}
}
void print(int a[]){
	int k=0;
	while(a[k]!=5001)
	k++;
	for(int i=0;i<k;i++)
	printf("%d ",a[i]);
}
int main(){
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	a[n]=5001;
	merge_sort(a,0,n-1);
    print(a);
	printf("\n");
	printf("%d",c);
	return 0;
}
